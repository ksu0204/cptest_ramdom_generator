const http = require("http");
const fs = require("fs");
const path = require("path");

const publicRoot = path.join(__dirname, "public");
const root = fs.existsSync(publicRoot) ? publicRoot : __dirname;
const host = process.env.HOST || "0.0.0.0";
const port = Number(process.env.PORT || 8080);

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon",
};

function resolveRequestPath(urlPath) {
  const rawPath = decodeURIComponent(urlPath.split("?")[0]);
  const withoutLeadingSlash = rawPath.replace(/^[/\\]+/, "");
  const requested = withoutLeadingSlash === "" ? "index.html" : withoutLeadingSlash;
  const safePath = path.normalize(requested).replace(/^(\.\.[/\\])+/, "");
  const target = path.resolve(root, safePath);
  return target.startsWith(root) ? target : path.join(root, "index.html");
}

const server = http.createServer((req, res) => {
  const filePath = resolveRequestPath(req.url || "/");

  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      res.end("404 Not Found");
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "content-type": mimeTypes[ext] || "application/octet-stream",
      "cache-control": "no-store",
    });
    res.end(data);
  });
});

server.listen(port, host, () => {
  console.log(`C 실습 랜덤 문제 생성기 실행 중`);
  console.log(`Local:   http://localhost:${port}`);
  console.log(`Network: http://<이_PC의_IP주소>:${port}`);
  console.log("종료하려면 Ctrl+C를 누르세요.");
});

@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0share_public_link.ps1"
pause

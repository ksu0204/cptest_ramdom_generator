@echo off
cd /d "%~dp0"
echo C practice random generator
echo.
echo Open this URL on this PC:
echo   http://localhost:8080
echo.
echo To access from another device on the same network, use:
echo   http://THIS_PC_IP_ADDRESS:8080
echo.
set "NODE_CMD=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE_CMD%" (
  set "NODE_CMD=node"
)
where "%NODE_CMD%" >nul 2>nul
if errorlevel 1 if not exist "%NODE_CMD%" (
  echo Node.js was not found.
  echo Install Node.js from https://nodejs.org or upload index.html to a static hosting service.
  pause
  exit /b 1
)
"%NODE_CMD%" server.js
pause

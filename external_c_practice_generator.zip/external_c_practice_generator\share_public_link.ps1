$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Port = if ($env:PORT) { [int]$env:PORT } else { 8080 }
$ToolsDir = Join-Path $Root "tools"
$Cloudflared = Join-Path $ToolsDir "cloudflared.exe"

function Find-Node {
  $codexNode = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
  if (Test-Path $codexNode) {
    return $codexNode
  }

  $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if ($nodeCommand) {
    return $nodeCommand.Source
  }

  throw "Node.js를 찾을 수 없습니다. https://nodejs.org 에서 Node.js를 설치한 뒤 다시 실행하세요."
}

function Ensure-Cloudflared {
  if (Test-Path $Cloudflared) {
    return
  }

  New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
  $downloadUrl = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"

  Write-Host "cloudflared를 처음 한 번 다운로드합니다..."
  Write-Host $downloadUrl
  Invoke-WebRequest -Uri $downloadUrl -OutFile $Cloudflared
}

function Start-LocalServer {
  $node = Find-Node
  $existing = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
  if ($existing) {
    Write-Host "이미 http://localhost:$Port 에서 서버가 실행 중입니다."
    return
  }

  Write-Host "로컬 서버를 시작합니다: http://localhost:$Port"
  $command = "`$env:HOST='0.0.0.0'; `$env:PORT='$Port'; & '$node' '$Root\server.js'"
  Start-Process powershell -ArgumentList "-NoExit", "-Command", $command -WindowStyle Minimized | Out-Null
  Start-Sleep -Seconds 2
}

Start-LocalServer
Ensure-Cloudflared

Write-Host ""
Write-Host "공개 링크를 생성합니다. 아래에 표시되는 https://...trycloudflare.com 주소를 공유하세요."
Write-Host "이 창을 닫거나 Ctrl+C를 누르면 외부 링크도 종료됩니다."
Write-Host ""

& $Cloudflared tunnel --url "http://localhost:$Port"

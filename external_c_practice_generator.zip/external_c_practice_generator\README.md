# C 실습 랜덤 문제 생성기

이 폴더는 외부 실행/배포용 패키지입니다. 앱은 `index.html` 하나로 동작하는 정적 웹페이지라서 별도 데이터베이스나 인터넷 연결이 필요 없습니다.

## 바로 실행

Windows에서 `run_windows.bat`을 더블클릭한 뒤 브라우저에서 아래 주소를 엽니다.

```text
http://localhost:8080
```

다른 기기에서 같은 와이파이/랜에 접속하려면 이 PC의 IP 주소를 사용합니다.

```text
http://이_PC의_IP주소:8080
```

Windows 방화벽에서 Node.js 또는 8080 포트 허용이 필요할 수 있습니다.

## 외부 공개 링크 만들기

가장 안전하게 고정 링크를 만들려면 `public/index.html`을 GitHub Pages, Netlify, Vercel, Cloudflare Pages 같은 정적 호스팅에 업로드하세요. 자세한 방법은 `PUBLIC_LINK_GUIDE.md`에 정리되어 있습니다.
GitHub Pages를 사용할 경우 저장소 루트에 `public/index.html`을 `index.html` 이름으로 업로드하고, `Settings > Pages`에서 `Deploy from a branch`를 선택하면 됩니다.

임시 링크가 필요하면 `share_public_link.bat`을 실행하면 됩니다. 로컬 서버를 시작한 뒤 Cloudflare Quick Tunnel로 공개 링크를 만듭니다.
PowerShell에 직접 복사해서 실행할 수 있는 완성 코드는 `DEPLOY_URL_COPY_CODE.md`에 들어 있습니다.

처음 실행할 때는 `tools/cloudflared.exe`를 자동 다운로드합니다. 실행 창에 아래와 비슷한 주소가 나타나면 그 링크를 공유하면 됩니다.

```text
https://random-name.trycloudflare.com
```

이 공개 링크는 실행 창이 열려 있는 동안만 유지됩니다. 창을 닫거나 `Ctrl+C`를 누르면 링크 접속도 종료됩니다.

주의: 공개 링크를 가진 사람은 누구나 페이지에 접속할 수 있습니다. 이 패키지의 서버는 `public` 폴더만 공개하도록 제한되어 있으며, 앱은 브라우저에서만 문제를 생성하므로 서버에 사용자의 생성 결과를 저장하지 않습니다.

## Node로 실행

Node.js가 설치된 환경에서는 다음 명령으로 실행할 수 있습니다.

```bash
npm start
```

또는:

```bash
node server.js
```

포트를 바꾸려면:

```bash
PORT=3000 node server.js
```

Windows PowerShell:

```powershell
$env:PORT=3000; node server.js
```

## 정적 호스팅 배포

GitHub Pages, Netlify, Vercel, Cloudflare Pages 같은 정적 호스팅에는 `index.html`만 업로드해도 됩니다.

서버 기능은 파일을 전달하기 위한 선택 사항이며, 문제 생성 기능은 브라우저 안에서 실행됩니다. 정적 호스팅에는 `public/index.html`을 업로드하는 것을 권장합니다.

# 외부 링크로 접속하게 만드는 방법

가장 안전한 방법은 `public/index.html`을 정적 호스팅에 올리는 것입니다. 이 앱은 서버 저장소나 데이터베이스가 필요 없어서 HTML 파일 하나만 올려도 외부 링크가 만들어집니다.

## 방법 1. Netlify Drop

1. `external_c_practice_generator/public` 폴더를 준비합니다.
2. 브라우저에서 `https://app.netlify.com/drop`에 접속합니다.
3. `public` 폴더를 드래그 앤 드롭합니다.
4. 생성된 `https://...netlify.app` 링크를 공유합니다.

## 방법 2. GitHub Pages

GitHub Pages는 정적 파일을 저장소에서 바로 배포할 수 있습니다. 이 프로젝트는 빌드 과정이 필요 없으므로 `index.html`만 올리면 됩니다.

1. GitHub에 로그인한 뒤 새 저장소를 만듭니다.
2. 저장소 이름은 원하는 이름으로 정합니다. 예: `c-practice-generator`
3. `external_c_practice_generator/public/index.html` 파일을 저장소 루트에 업로드합니다.
4. 저장소의 `Settings` 탭으로 이동합니다.
5. 왼쪽 메뉴에서 `Pages`를 선택합니다.
6. `Build and deployment`의 `Source`를 `Deploy from a branch`로 설정합니다.
7. `Branch`를 `main`, 폴더를 `/root`로 선택한 뒤 저장합니다.
8. 잠시 기다린 뒤 아래 형식의 주소로 접속합니다.

```text
https://GitHub아이디.github.io/저장소이름/
```

예시:

```text
https://myname.github.io/c-practice-generator/
```

GitHub Pages 반영에는 몇 분이 걸릴 수 있습니다. GitHub 공식 문서에서는 변경사항 게시까지 최대 10분 정도 걸릴 수 있다고 안내합니다.

## 방법 3. 현재 PC를 임시 공개 링크로 열기

`share_public_link.bat`을 실행하면 Cloudflare Quick Tunnel을 이용해 `https://...trycloudflare.com` 링크를 만들 수 있습니다.

이 방식의 특징:

- PC가 켜져 있고 실행 창이 열려 있는 동안만 링크가 유지됩니다.
- 처음 실행 시 `cloudflared.exe`를 다운로드합니다.
- 외부 링크를 가진 사람은 누구나 접속할 수 있습니다.
- 이 패키지의 서버는 `public` 폴더만 공개하도록 제한되어 있습니다.

실행 후 창에 표시되는 `https://...trycloudflare.com` 주소를 공유하면 됩니다.

# 배포 URL 생성용 복사 코드

아래 PowerShell 코드를 `external_c_practice_generator` 폴더에서 실행하면 공개 접속 URL이 생성됩니다.

```powershell
$ErrorActionPreference = "Stop"
$Port = 8080
$Root = (Get-Location).Path
$ToolsDir = Join-Path $Root "tools"
$Cloudflared = Join-Path $ToolsDir "cloudflared.exe"
$Node = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"

if (!(Test-Path $Node)) {
  $NodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if (!$NodeCommand) {
    throw "Node.js가 필요합니다. https://nodejs.org 에서 설치한 뒤 다시 실행하세요."
  }
  $Node = $NodeCommand.Source
}

if (!(Test-Path $Cloudflared)) {
  New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
  Invoke-WebRequest `
    -Uri "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" `
    -OutFile $Cloudflared
}

$existing = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
if (!$existing) {
  Start-Process powershell `
    -ArgumentList "-NoExit", "-Command", "`$env:HOST='0.0.0.0'; `$env:PORT='$Port'; & '$Node' '$Root\server.js'" `
    -WindowStyle Minimized
  Start-Sleep -Seconds 2
}

Write-Host ""
Write-Host "아래에 표시되는 https://...trycloudflare.com 주소가 배포용 URL입니다."
Write-Host "이 창을 닫으면 배포 URL도 종료됩니다."
Write-Host ""
& $Cloudflared tunnel --url "http://localhost:$Port"
```

주의:

- 이 방식은 임시 공개 URL입니다.
- 링크를 가진 사람은 누구나 접속할 수 있습니다.
- 이 패키지의 서버는 `public` 폴더만 공개합니다.
- 고정 URL이 필요하면 `public/index.html`을 Netlify, GitHub Pages, Vercel, Cloudflare Pages 등에 업로드하세요.
